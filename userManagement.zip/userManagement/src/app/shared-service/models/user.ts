export interface User {
    id: number;    
    name: string;
    surname: string;
    birthDate: string
    phone: number,
    city: string,
    street: string,
    numberSeq?: number
}
