export const environment = {
  production: true,
  findall: "config/pfindall.json",
  find: "config/pfind.json",
  edit: "config/pedit.json",
  remove: "config/premove.json"
};
